package com.soft.infogan.test.trading;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.soft.infogain.trading.MarketWatcher;
import com.soft.infogain.trading.Portfolio;
import com.soft.infogain.trading.StockBroker;
import com.soft.infogain.trading.dto.Stock;
@RunWith(MockitoJUnitRunner.class)
public class DoReturnTest {
	@Mock
	MarketWatcher marketWatcher;
	@Mock
	Portfolio portfolio;

	StockBroker broker;
	
	Stock globalStock =  when(Mockito.mock(Stock.class).getPrice()).thenReturn(BigDecimal.ONE).getMock();

	@Before
	public void setUp() {
		broker = new StockBroker(marketWatcher);
	}
	

	//This test will fail
	@Test
	public void doReturn_is_not_type_safe() throws Exception {
		//then return is type safe- It has to return a BigDecimal
		when(portfolio.getCurrentValue()).thenReturn(BigDecimal.ONE);
		//method call works fine
		portfolio.getCurrentValue();
		//returning a String instead of BigDecimal
		doReturn("See returning a String").when(portfolio.getCurrentValue());
		//this call will fail
		portfolio.getCurrentValue();
				
	}
	
	@Test
	public void doReturn_usage() throws Exception {
		List<String> list = new ArrayList<String>();
		List<String> spy = spy(list);
		
		//doReturn fixed the issue
		doReturn("now reachable").when(spy).get(0);
		assertEquals("now reachable", spy.get(0));
	}
}
