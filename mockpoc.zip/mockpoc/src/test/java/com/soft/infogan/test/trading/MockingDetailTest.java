package com.soft.infogan.test.trading;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.soft.infogain.trading.MarketWatcher;
import com.soft.infogain.trading.Portfolio;
import com.soft.infogain.trading.StockBroker;
import com.soft.infogain.trading.dto.Stock;
@RunWith(MockitoJUnitRunner.class)
public class MockingDetailTest {
	@Mock
	MarketWatcher marketWatcher;
	@Mock
	Portfolio portfolio;

	StockBroker broker;
	
	Stock globalStock =  when(Mockito.mock(Stock.class).getPrice()).thenReturn(BigDecimal.ONE).getMock();

	@Before
	public void setUp() {
		broker = new StockBroker(marketWatcher);
	}
	
	@Test
	public void mocking_details() throws Exception {
		Portfolio pf1 = Mockito.mock(Portfolio.class, Mockito.RETURNS_MOCKS);
		
		BigDecimal result = pf1.getAvgPrice(globalStock);
		assertNotNull(result);
		assertTrue(Mockito.mockingDetails(pf1).isMock());
		
		Stock myStock = new Stock(null, null, null);
		Stock spy = spy(myStock);
		assertTrue(Mockito.mockingDetails(spy).isSpy());
}}
