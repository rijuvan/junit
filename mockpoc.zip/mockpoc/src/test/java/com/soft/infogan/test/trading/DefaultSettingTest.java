package com.soft.infogan.test.trading;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.soft.infogain.trading.MarketWatcher;
import com.soft.infogain.trading.Portfolio;
import com.soft.infogain.trading.StockBroker;
import com.soft.infogain.trading.dto.Stock;

@RunWith(MockitoJUnitRunner.class)
public class DefaultSettingTest {
	@Mock
	MarketWatcher marketWatcher;
	@Mock
	Portfolio portfolio;

	StockBroker broker;
	
	Stock globalStock =  when(Mockito.mock(Stock.class).getPrice()).thenReturn(BigDecimal.ONE).getMock();

	@Before
	public void setUp() {
		broker = new StockBroker(marketWatcher);
	}
	@Test
	public void changing_default() throws Exception {
		Stock aCorp = new Stock("A", "A Corp", new BigDecimal(11.20));
		Portfolio pf = Mockito.mock(Portfolio.class);
		//default null is returned
		assertNull(pf.getAvgPrice(aCorp));
		
		Portfolio pf1 = Mockito.mock(Portfolio.class, Mockito.RETURNS_SMART_NULLS);
		//a smart null is returned
		System.out.println("#1 "+pf1.getAvgPrice(aCorp));
		assertNotNull(pf1.getAvgPrice(aCorp));
		
		Portfolio pf2 = Mockito.mock(Portfolio.class, Mockito.RETURNS_MOCKS);
		//a smart null is returned
		System.out.println("#2 "+pf2.getAvgPrice(aCorp));
		assertNotNull(pf2.getAvgPrice(aCorp));
		
		Portfolio pf3 = Mockito.mock(Portfolio.class, Mockito.RETURNS_DEEP_STUBS);
		//a smart null is returned
		System.out.println("#3 "+pf3.getAvgPrice(aCorp));
		assertNotNull(pf3.getAvgPrice(aCorp));
	}
	
	@Test
	public void resetMock() throws Exception {
		Stock aCorp = new Stock("A", "A Corp", new BigDecimal(11.20));
		
		Portfolio portfolio = Mockito.mock(Portfolio.class);
		when(portfolio.getAvgPrice(eq(aCorp))).thenReturn(BigDecimal.ONE);
		assertNotNull(portfolio.getAvgPrice(aCorp));
		Mockito.reset(portfolio);
		//Resets the stub, so getAvgPrice returns NULL
		assertNull(portfolio.getAvgPrice(aCorp));
	}
	
}
