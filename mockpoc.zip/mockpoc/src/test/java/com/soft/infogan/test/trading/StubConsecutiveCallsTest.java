package com.soft.infogan.test.trading;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.soft.infogain.trading.MarketWatcher;
import com.soft.infogain.trading.Portfolio;
import com.soft.infogain.trading.StockBroker;
import com.soft.infogain.trading.dto.Stock;
@RunWith(MockitoJUnitRunner.class)
public class StubConsecutiveCallsTest {
	@Mock
	MarketWatcher marketWatcher;
	@Mock
	Portfolio portfolio;

	StockBroker broker;
	
	Stock globalStock =  when(Mockito.mock(Stock.class).getPrice()).thenReturn(BigDecimal.ONE).getMock();

	@Before
	public void setUp() {
		broker = new StockBroker(marketWatcher);
	}
	
	@Test
	public void consecutive_calls() throws Exception {
		Stock stock = new Stock(null, null, null);
		when(portfolio.getAvgPrice(stock)).thenReturn(BigDecimal.TEN, BigDecimal.ZERO,BigDecimal.ONE);
		assertEquals(BigDecimal.TEN, portfolio.getAvgPrice(stock));
		assertEquals(BigDecimal.ZERO, portfolio.getAvgPrice(stock));
		assertEquals(BigDecimal.ONE, portfolio.getAvgPrice(stock));
		
	}
}
