package com.soft.infogan.test.trading;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.soft.infogain.trading.MarketWatcher;
import com.soft.infogain.trading.Portfolio;
import com.soft.infogain.trading.StockBroker;
import com.soft.infogain.trading.dto.Stock;

import static org.mockito.Mockito.verifyZeroInteractions;
@RunWith(MockitoJUnitRunner.class)
public class VerifyZeroOrMoreIntractionTest {
	@Mock MarketWatcher marketWatcher;
	@Mock Portfolio portfolio;
	StockBroker broker;
	Stock globalStock =  when(Mockito.mock(Stock.class).getPrice()).thenReturn(BigDecimal.ONE).getMock();
	@Before public void setUp() {
	broker = new StockBroker(marketWatcher);
	}
	
	@Test public void verify_zero_interaction() {
				
		verifyZeroInteractions(marketWatcher,portfolio);
}
	
	@Test

	public void verify_no_more_interaction() {
		Stock noStock = null;
		//portfolio.getAvgPrice(noStock);
		//portfolio.sell(null, 0);
		//verify(portfolio).getAvgPrice(eq(noStock));
		// this will fail as the sell method was invoked
		verifyNoMoreInteractions(portfolio);
	}
	
	
}
