package com.soft.infogan.test.trading;

import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InOrder;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.soft.infogain.trading.MarketWatcher;
import com.soft.infogain.trading.Portfolio;
import com.soft.infogain.trading.StockBroker;
import com.soft.infogain.trading.dto.Stock;
@RunWith(MockitoJUnitRunner.class)
public class InOrderTest {
	@Mock
	MarketWatcher marketWatcher;
	@Mock
	Portfolio portfolio;

	StockBroker broker;
	
	Stock globalStock =  when(Mockito.mock(Stock.class).getPrice()).thenReturn(BigDecimal.ONE).getMock();

	@Before
	public void setUp() {
		broker = new StockBroker(marketWatcher);
	}
	
	@Test
	public void inorder() throws Exception {
		Stock aCorp = new Stock("A", "A Corp", new BigDecimal(11.20));
		
		portfolio.getAvgPrice(aCorp);
		portfolio.getCurrentValue();
		marketWatcher.getQuote("X");
		portfolio.buy(aCorp);
		
		InOrder inOrder=inOrder(portfolio,marketWatcher);
		inOrder.verify(portfolio).getAvgPrice(isA(Stock.class));
		inOrder.verify(portfolio).getCurrentValue();
		inOrder.verify(marketWatcher).getQuote(anyString());
		inOrder.verify(portfolio).buy(isA(Stock.class));
	}
	
	//Order is not Guaranteed
	@Test 
	public void inorder2() throws Exception {
		Stock aCorp = new Stock("A", "A Corp",
		new BigDecimal(11.20));
		portfolio.getAvgPrice(aCorp);
		portfolio.getCurrentValue();
		marketWatcher.getQuote("X");
		portfolio.buy(aCorp);
		InOrder inOrder=inOrder(portfolio,marketWatcher);
		inOrder.verify(portfolio).buy(isA(Stock.class));
		inOrder.verify(portfolio).getAvgPrice(isA(Stock.class));
		}
	// Reordering the verification sequence
	@Test public void inorder3() throws Exception {
		Stock aCorp = new Stock("A", "A Corp", new
		BigDecimal(11.20));
		portfolio.getAvgPrice(aCorp);
		portfolio.getCurrentValue();
		marketWatcher.getQuote("X");
		portfolio.buy(aCorp);
		InOrder inOrder=inOrder(portfolio,marketWatcher);
		inOrder.verify(portfolio).getAvgPrice(isA(Stock.class));
		inOrder.verify(portfolio).getCurrentValue();
		inOrder.verify(marketWatcher).getQuote(anyString());
		inOrder.verify(portfolio).buy(isA(Stock.class));
		}
	
}
