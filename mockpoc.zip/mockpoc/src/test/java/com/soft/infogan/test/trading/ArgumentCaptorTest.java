package com.soft.infogan.test.trading;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.soft.infogain.trading.MarketWatcher;
import com.soft.infogain.trading.Portfolio;
import com.soft.infogain.trading.StockBroker;
import com.soft.infogain.trading.dto.Stock;
@RunWith(MockitoJUnitRunner.class)
public class ArgumentCaptorTest {
	@Mock
	MarketWatcher marketWatcher;
	@Mock
	Portfolio portfolio;

	StockBroker broker;
	
	Stock globalStock =  when(Mockito.mock(Stock.class).getPrice()).thenReturn(BigDecimal.ONE).getMock();

	@Before
	public void setUp() {
		broker = new StockBroker(marketWatcher);
	}
	
	@Test
	public void argument_captor() throws Exception {
		when(portfolio.getAvgPrice(isA(Stock.class))).thenReturn(
				new BigDecimal("10.00"));
		Stock aCorp = new Stock("A", "A Corp", new BigDecimal(11.20));
		when(marketWatcher.getQuote(anyString())).thenReturn(aCorp);
		broker.perform(portfolio, aCorp);
		
		ArgumentCaptor<String> arg = ArgumentCaptor.forClass(String.class);
		verify(marketWatcher).getQuote(arg.capture());
		assertEquals("A", arg.getValue());
		
		ArgumentCaptor<Stock> arg0 = ArgumentCaptor.forClass(Stock.class);
		ArgumentCaptor<Integer> arg1 = ArgumentCaptor.forClass(Integer.class);
		verify(portfolio).sell(arg0.capture(), arg1.capture());
		assertEquals("A", arg0.getValue().getSymbol());
		assertEquals(10, arg1.getValue().intValue());
	}
	
}
