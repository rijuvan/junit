package com.soft.infogan.test.trading;

import static org.junit.Assert.fail;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.soft.infogain.trading.MarketWatcher;
import com.soft.infogain.trading.Portfolio;
import com.soft.infogain.trading.StockBroker;
import com.soft.infogain.trading.dto.Stock;
@RunWith(MockitoJUnitRunner.class)
public class ThrowingExceptionTest {

	@Mock
	MarketWatcher marketWatcher;
	@Mock
	Portfolio portfolio;

	StockBroker broker;
	
	Stock globalStock =  when(Mockito.mock(Stock.class).getPrice()).thenReturn(BigDecimal.ONE).getMock();

	@Before
	public void setUp() {
		broker = new StockBroker(marketWatcher);
	}
	
	@Test(expected = IllegalStateException.class)
	public void throwsException() throws Exception {
when(portfolio.getAvgPrice(isA(Stock.class))).
thenThrow(new IllegalStateException("Database down"));

		portfolio.getAvgPrice(new Stock(null, null, null));
		fail("Should throw exception");
	}
	
	@Test(expected = IllegalStateException.class)
	public void throwsException_void_methods() throws Exception {
		doThrow(new IllegalStateException()).when(portfolio).buy(isA(Stock.class));

		portfolio.buy(new Stock(null, null, null));
		fail("Should throw exception");
	}
}
