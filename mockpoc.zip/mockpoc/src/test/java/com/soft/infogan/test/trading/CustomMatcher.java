package com.soft.infogan.test.trading;

import static org.mockito.Mockito.when;

import java.math.BigDecimal;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import static org.mockito.Mockito.*;
import com.soft.infogain.matcher.BlueChipStockMatcher;
import com.soft.infogain.matcher.InfogainStockMatcher;
import com.soft.infogain.trading.MarketWatcher;
import com.soft.infogain.trading.Portfolio;
import com.soft.infogain.trading.StockBroker;
import com.soft.infogain.trading.dto.Stock;
@RunWith(MockitoJUnitRunner.class)
public class CustomMatcher {

	@Mock
	MarketWatcher marketWatcher;
	@Mock
	Portfolio portfolio;

	StockBroker broker;
	
	Stock globalStock =  when(Mockito.mock(Stock.class).getPrice()).thenReturn(BigDecimal.ONE).getMock();

	@Before
	public void setUp() {
		broker = new StockBroker(marketWatcher);
	}

	@Test
	public void argument_matcher() {
	when(portfolio.getAvgPrice(isA(Stock.class))).thenReturn(new BigDecimal("10.00"));
	Stock blueChipStock = new Stock("FB", "FB Corp", new BigDecimal(1000.00));
	Stock otherStock = new Stock("XY", "XY Corp", new BigDecimal(5.00));
	when(marketWatcher.getQuote(argThat(new BlueChipStockMatcher()))).thenReturn(blueChipStock);
	when(marketWatcher.getQuote(argThat(new InfogainStockMatcher()))).thenReturn(otherStock);
	broker.perform(portfolio, blueChipStock);
	verify(portfolio).sell(blueChipStock,10);
	broker.perform(portfolio, otherStock);
	verify(portfolio, never()).sell(otherStock,10);
	}
}
