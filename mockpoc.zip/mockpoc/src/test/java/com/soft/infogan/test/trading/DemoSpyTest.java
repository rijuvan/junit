package com.soft.infogan.test.trading;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.soft.infogain.trading.MarketWatcher;
import com.soft.infogain.trading.Portfolio;
import com.soft.infogain.trading.StockBroker;
import com.soft.infogain.trading.dto.Stock;
@RunWith(MockitoJUnitRunner.class)
public class DemoSpyTest {
	@Mock
	MarketWatcher marketWatcher;
	@Mock
	Portfolio portfolio;

	StockBroker broker;
	
	Stock globalStock =  when(Mockito.mock(Stock.class).getPrice()).thenReturn(BigDecimal.ONE).getMock();

	@Before
	public void setUp() {
		broker = new StockBroker(marketWatcher);
	}
	@Test
	public void spying() throws Exception {
		Stock realStock = new Stock("A", "Company A", BigDecimal.ONE);
		Stock spyStock = spy(realStock);
		
        //call real method from  spy
        assertEquals("A", spyStock.getSymbol());
        //Changing value using spy
        spyStock.updatePrice(BigDecimal.ZERO);
         //verify spy has the changed value
        assertEquals(BigDecimal.ZERO, spyStock.getPrice());
        //Stubbing method
        when(spyStock.getPrice()).thenReturn(BigDecimal.TEN);
        
        //Changing value using spy
        spyStock.updatePrice(new BigDecimal("7"));
        
        //Stubbed method value 10.00  is returned NOT 7
        assertNotEquals(new BigDecimal("7") , spyStock.getPrice());
        //Stubbed method value 10.00
        assertEquals(BigDecimal.TEN,  spyStock.getPrice());

	}
}
