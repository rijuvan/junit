package com.soft.infogain.answer;

import com.soft.infogain.trading.dto.Stock;

public interface MarketWatcher {
   Stock getQuote(String symbol);
}
