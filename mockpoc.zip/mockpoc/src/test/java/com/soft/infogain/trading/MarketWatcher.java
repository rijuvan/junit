package com.soft.infogain.trading;

import com.soft.infogain.trading.dto.Stock;

public interface MarketWatcher {
   Stock getQuote(String symbol);
}
