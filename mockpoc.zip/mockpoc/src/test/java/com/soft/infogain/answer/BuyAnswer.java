package com.soft.infogain.answer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import com.soft.infogain.trading.dto.Stock;

public class BuyAnswer implements Answer<Object>{
private Map<String, List<Stock>> stockMap = new HashMap<String, List<Stock>>();
public Object answer(InvocationOnMock invocation) throws
Throwable
{
Stock newStock = (Stock)invocation.getArguments()[0];
List<Stock> stocks = stockMap.get(newStock.getSymbol());
if(stocks != null) {
stocks.add(newStock);
}else {
stocks = new ArrayList<Stock>();
stocks.add(newStock);
stockMap.put(newStock.getSymbol(), stocks);
}
return null;
}
}
