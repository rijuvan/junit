package com.soft.infogain.answer;

import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.runners.VerboseMockitoJUnitRunner;

import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

import com.soft.infogain.trading.MarketWatcher;
import com.soft.infogain.trading.Portfolio;
import com.soft.infogain.trading.StockBroker;
import com.soft.infogain.trading.dto.Stock;

//@RunWith(MockitoJUnitRunner.class)
@RunWith(VerboseMockitoJUnitRunner.class)
public  class TotalPriceAnswerTest {
	private Map<String, List<Stock>> stockMap = new HashMap<String, List<Stock>>();
	@Mock
	MarketWatcher marketWatcher;
	@Mock
	Portfolio portfolio;

	StockBroker broker;
	
	Stock globalStock =  when(Mockito.mock(Stock.class).getPrice()).thenReturn(BigDecimal.ONE).getMock();

	@Before
	public void setUp() {
		broker = new StockBroker(marketWatcher);
	}

	@Test
	public void answering() throws Exception {
	stockMap.clear();
	doAnswer(new BuyAnswer()).when(portfolio).buy(isA(Stock.class));
	when(portfolio.getCurrentValue()).then(new TotalPriceAnswer());
	portfolio.buy(new Stock("A", "A", BigDecimal.TEN));
	portfolio.buy(new Stock("B", "B", BigDecimal.ONE));
	//assertEquals(new BigDecimal("11"),portfolio.getCurrentValue());
	}
}
