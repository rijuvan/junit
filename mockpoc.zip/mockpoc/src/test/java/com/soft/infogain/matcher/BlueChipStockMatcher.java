package com.soft.infogain.matcher;

import org.mockito.ArgumentMatcher;

public class BlueChipStockMatcher extends ArgumentMatcher<String>{
@Override
public boolean matches(Object symbol) {
return "FB".equals(symbol) ||"AAPL".equals(symbol);
}
}

