package com.soft.infogain.answer;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import com.soft.infogain.trading.dto.Stock;

public class TotalPriceAnswer implements Answer<BigDecimal>{
private Map<String, List<Stock>> stockMap = new HashMap<String, List<Stock>>();
public BigDecimal answer(InvocationOnMock invocation)
throws Throwable {
BigDecimal totalPrice = BigDecimal.ZERO;
for(String stockId: stockMap.keySet()) {
for(Stock stock:stockMap.get(stockId)) {
totalPrice = totalPrice.add(stock.getPrice());
}
}
return totalPrice;
}
}
