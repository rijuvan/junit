package com.soft.infogain.matcher;

public class InfogainStockMatcher extends BlueChipStockMatcher{
@Override
public boolean matches(Object symbol) {
return !super.matches(symbol);
}
}