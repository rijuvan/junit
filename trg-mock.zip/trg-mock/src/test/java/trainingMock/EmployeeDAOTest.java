package trainingMock;

import java.util.LinkedList;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

public class EmployeeDAOTest {

	private EmployeeDAO employeeDAO;

	private Employee e1;
	private Employee e2;
	private Employee e3;

	@Before
	public void setUp() {
		employeeDAO = mock(EmployeeDAO.class);
		e1 = new Employee(100, "Alex");
		e2 = new Employee(200, "Jack");
		e3 = new Employee(300, "Navven");
		when(employeeDAO.addEmloyee(e1)).thenReturn(e1.getEmpId());
		when(employeeDAO.addEmloyee(e3)).thenReturn(e3.getEmpId());
		when(employeeDAO.addEmloyee(e2)).thenReturn(e2.getEmpId());
	}

	@Test
	public void addEmployeeTest() {

		assertEquals(100, employeeDAO.addEmloyee(e1));
		assertEquals(200, employeeDAO.addEmloyee(e2));

	}

	@Test
	public void verifyAddEmployee() {
		employeeDAO.addEmloyee(e1);
		employeeDAO.addEmloyee(e2);
		verify(employeeDAO).addEmloyee(e1);
	}

	@Test
	public void promoteTest() {

		employeeDAO.promoteEmployee(e3);

		verify(employeeDAO).promoteEmployee(e3);

	}

	@Test
	public void findByNameTest() {

		when(employeeDAO.findEmployeeByName("Alex")).thenReturn("Calling find by Name");

		System.out.println(employeeDAO.findEmployeeByName("Alex"));

	}

	@Test
	public void findByNameTest2() {

		when(employeeDAO.findEmployeeByName(anyString())).thenReturn("This is demo data");

		System.out.println(employeeDAO.findEmployeeByName("Alex123"));

		System.out.println(employeeDAO.findEmployeeByName("Al3"));

	}

	@Test(expected = UnsupportedOperationException.class)
	public void findTest() {
		when(employeeDAO.findEmployee(isA(Employee.class))).thenThrow(new UnsupportedOperationException());

		employeeDAO.findEmployee(e3);
	}

	@Test
	@Ignore
	public void allocateDeptTest() {
		doThrow(new IllegalStateException()).when(employeeDAO).allocateDept();

		employeeDAO.allocateDept();
	}

	@Test
	public void managmentRoleTest() {
		when(employeeDAO.promoteToManagmentRole(isA(Employee.class))).thenReturn(100, 200, 300);
		assertEquals(100, employeeDAO.promoteToManagmentRole(e1));
		assertEquals(200, employeeDAO.promoteToManagmentRole(e1));
		assertEquals(300, employeeDAO.promoteToManagmentRole(e1));
		assertEquals(300, employeeDAO.promoteToManagmentRole(e1));

		// reset(employeeDAO);
		assertNotNull(employeeDAO);
		assertEquals(300, employeeDAO.promoteToManagmentRole(e1));
	}

	@Test
	public void spyTest() {
		List list = new LinkedList();
		List spy = spy(list);

		when(spy.size()).thenReturn(100);
		spy.add("one");
		spy.add("two");

		System.out.println(spy.size());
		System.out.println(spy.get(0));

		verify(spy).add("one");
		verify(spy).add("two");

		// stubbing get method

		when(spy.get(0)).thenReturn("one");

		System.out.println("**********" + spy.get(0));

		List list1 = new LinkedList();
		List spy1 = spy(list1);

		// Impossible: real method is called so spy.get(0) throws
		// IndexOutOfBoundsException (the list is yet empty)
		// when(spy1.get(0)).thenReturn("foo");

		// You have to use doReturn() for stubbing
		doReturn("foo").when(spy1).get(0);

	}

}
