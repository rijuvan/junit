package trainingMock;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import java.util.List;

import org.junit.Test;
import static org.junit.Assert.*;

public class MockTest {
	
	
	
	@Test
	public void testList()
	{
		List list=mock(List.class);
		list.add("one");
		list.add("two");
		//stubbing the methods of list
		
		//swhen(list.get(0)).thenReturn("this is first object");
		System.out.println(list.get(0));
		System.out.println(list.size());
		
		assertNotNull(list);
		
	}

}
