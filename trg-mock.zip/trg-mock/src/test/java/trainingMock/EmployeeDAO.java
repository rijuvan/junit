package trainingMock;

public interface EmployeeDAO {
	
	public int addEmloyee(Employee e);

	public void promoteEmployee(Employee e);
	public int promoteToManagmentRole(Employee e);
	
	public String findEmployeeByName(String name);
	
	public int findEmployee(Employee e);
	
	public void allocateDept();
}
