import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class PriceCalculatorTest {

   @Test 
   public void calculateStandardGST() {
     PriceCalculator calculator = new PriceCalculator();
     double gst = calculator.calculatePriceWithGST(10);
     assertEquals(gst, 5.0 , 0.0);
   }

//   @Test 
//   public void calculateReducedGST() {
//     PriceCalculator calculator = new PriceCalculator();
//     double gst = calculator.calculatePriceWithReducedGST(10);
//     assertEquals(gst, -5.0 , 0.0);
//   }

}

