
public class PriceCalculator {
public double calculatePriceWithGST(int  value)

{
	double gst=0;
	return gst =( 100*value/100)*0.5;
}


public double calculatePriceWithReducedGST(int value)

{
	return (100*value/200-value);
}
}
