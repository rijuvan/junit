import junit.framework.*;

public class BadExampleTest extends TestCase {
    private Runnable runnable;

    public class DelayedHello
        implements Runnable {

        private int count;
        private Thread worker;

        private DelayedHello(int count) {
            this.count = count;
            worker = new Thread(this);
            worker.start();
        }

        public void run() {
            try {
                Thread.sleep(count);
                System.out.println(
                "Delayed Hello World");

            } catch(InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void testExampleThread()
            throws Throwable {

        System.out.println("Hello, World");       //1
        runnable = new DelayedHello(5000);        //2
        System.out.println("Goodbye, World");     //3
    }

}