import org.junit.*;
import org.junit.runner.RunWith;

import java.util.ArrayList;

import junit.framework.TestCase;
 @RunWith(value=org.junit.internal.runners.JUnit38ClassRunner.class)
 public class Junit38RunwithDemo extends TestCase {
 
  public void testMultiplication() {
    // Testing if 3*2=6:
    assertEquals("Multiplication", 6, 3*2);
  }
 
  public void testCreativeMultiplication() {
    // Testing if 3*2=6:
    assertEquals("Creative multiplication", 6, 3*2);
  }
 
  public void testException1() {
    try {
      ArrayList<Object> emptyList = new ArrayList<Object>();
      Object o = emptyList.get(0);   // throws IndexOutOfBoundsException
      fail("no exception");
    }
    catch (Exception e) {
    }
  }
 
  public void testException2() {
    try {
      int i = 0;
    }
    catch (Exception e) {
      fail("exception");
    }
  }
 
 }