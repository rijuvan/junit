package jdbcTest;

import java.sql.*;

import org.junit.After;
import org.junit.Before;


public class JdbcApplication {
	
	private Connection conn;
	private Statement stmt;
	private ResultSet result;

	public Connection setConnection()
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			conn=DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE","hr","infg");
			
			
		}catch(Exception e)
		{
		e.printStackTrace();
		}
		
		return conn;
		
	}
	
	
	
	public Statement getStatement()
	{
		
		try {
			stmt=conn.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return stmt;
	}
	
	public ResultSet getResult(String query)
	{
		
		
		try {
			result =stmt.executeQuery(query);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	

	public void closeAll()
	{
		
	try {
		stmt.close();
		conn.close();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	
	}

}
