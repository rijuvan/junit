package jdbcTest;
import java.sql.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertNotNull;
public class JdbcTest {
	JdbcApplication app;
	@Before
	public void appInitialize()
	{
	app=new JdbcApplication();
	}

@Test  
	public void ConnNotNull()
	{
		
		
		Connection conn=app.setConnection();
		assertNotNull(conn);
		
		
		
		
	}


	

	@Test
	public void getData()
	{
		Connection conn=app.setConnection();
		Statement stmt=app.getStatement();
		ResultSet rs=app.getResult("select * from employees");
		
		
	}

	

}
