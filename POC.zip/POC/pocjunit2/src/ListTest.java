import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;



	public class ListTest {
		private ArrayList<String> myList;
		@Before
		public void setUp() {
		myList = new ArrayList<String>();
		}
		@Test
		public void addElement() {
		myList.add("hello");
		assertEquals(1, myList.size());
		assertEquals("hello", myList.get(0));
		}
		@Test
		public void emptyList() {
		assertEquals(0, myList.size());
		}
		
		
		}

