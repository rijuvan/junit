import org.junit.*;
public class IgnoreTest {
 
	@Ignore("Not Ready to Run")  
	@Test
	public void divisionWithException() {  
	  System.out.println("Method is not ready yet");
	}  
 
}