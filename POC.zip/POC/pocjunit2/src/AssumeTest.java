
	import org.junit.*;
	import static org.hamcrest.CoreMatchers.*;
	import static org.junit.Assume.*;
	import static org.junit.Assert.assertSame;
	class One
	{
		
	}
	
	
	public class AssumeTest {
		 One o1;
		 One o2;
	   @Test
	    public void testA(){
	
	        int x = 7;//1 ,2 3, 10
	
	        assumeThat( x, is(7) );
	
	        System.out.println("assumption is true!");
	
	    }
	   @Before
	   public void setUp()
	   {
		    o1=new One();
			 o2=o1;
	   }
	 @Test  public void testB()
	   {
		 int x=20; 
		 
		 boolean i;
		 i=x>10;
		 
		 assumeTrue(i);
		 System.out.println("asummtion is true ");
		 
		 
	   }
	 @Test
public void testC()
	{
		 
		 assertSame(o1,o2);
		
	}
	 
	}


