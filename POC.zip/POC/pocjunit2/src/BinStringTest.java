import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
public class BinStringTest {
private BinString binString;

@Before
public void setUp() {
binString = new BinString();
}
@Test
public void testSumFunction() {
int expected = 0;
assertEquals(expected, binString.sum(""));
expected = 100;
assertEquals(expected, binString.sum("d"));
expected = 265;
assertEquals(expected, binString.sum("Add"));
}
@Test
public void testBinariseFunction() {
String expected = "101";
assertEquals(expected, binString.binarise(5));
expected = "11";
assertEquals(expected, binString.binarise(3));

}
@Test
public void testTotalConversion() {
String expected = "1000001";
assertEquals(expected, binString.convert("A"));
}
}
