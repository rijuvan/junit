
import org.junit.*;
public class ExceptionTest {
 
	@Test(expected = ArithmeticException.class)  
	public void divisionWithException() {  
	  int i = 1/0;
	}  
 
}