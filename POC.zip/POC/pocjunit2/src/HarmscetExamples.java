import java.util.Arrays;
import java.util.List;

import org.junit.Test;

import static org.junit.matchers.JUnitMatchers.*;
import static org.junit.Assert.assertThat;
 
public class HarmscetExamples {
 
  //Hamcrest with Collections and Arrays:
  static final String[] array = { "A", "B", "C" };
  static final List<String> list = Arrays.asList(array);
 
 

@Test
  public void arrayOfItemsInList () {
  String[] expected = { "A", "B", "C" };
    assertThat(list, hasItems(expected));
  }
 
  @Test
  public void itemInAList () {
    assertThat(list, hasItem("A"));
  }
 
  @Test
  public void itemsInAList () {
    assertThat(list, hasItems("A", "C"));
  }
}