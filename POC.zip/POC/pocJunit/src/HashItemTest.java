import java.util.Arrays;
import static org.hamcrest.CoreMatchers.*;

import static org.junit.Assert.*;
import java.util.List;

import org.junit.Test;


public class HashItemTest {
	@Test
	public void verify_collection_values() throws Exception {
	List<Double> salary =Arrays.asList(50.0, 200.0, 500.0);
	assertThat(salary, hasItem(50.00));
	assertThat(salary, hasItems(50.00, 200.00));
	assertThat(salary, not(hasItem(1.00)));
	}
}
