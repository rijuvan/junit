package extra;
import org.junit.Ignore;
import org.junit.experimental.theories.*;
import org.junit.runner.RunWith;
@RunWith(Theories.class)
public class Theorytest {
	@DataPoint public static String name="infogain";
	@DataPoint public static int age1= 1;
	@DataPoint public static int age2= 12;
	@DataPoint public static int age3= 11;
	
	@DataPoints public static int[] ages ={14, 13, 52};
	@Theory
	@Ignore
	public void start(String aName)
	{
		System.out.println("This is theory" +aName);
	}
	
	@Theory
	public void tstart(int vage)
	{
		System.out.println("This is theory" +vage);
	}

}
