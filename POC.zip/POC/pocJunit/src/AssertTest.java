import org.junit.Assert;
import org.junit.Test;
public class AssertTest {
@Test
public void assertTrueAndFalseTest() throws Exception {
Assert.assertTrue(true);
Assert.assertFalse(false);
}
@Test
public void assertNullAndNotNullTest() throws Exception {
Object myObject = null;
Assert.assertNull(myObject);
myObject = new String("Some value");
Assert.assertNotNull(myObject);
}

@Test
public void assertNotSameTest() throws Exception {
Integer i = new Integer("5");
//Integer j=i;
Integer j = new Integer("5");;
Assert.assertNotSame(i , j);  // checks same refrence
}

//Exception testing
@Test(expected=RuntimeException.class)
public void exception() {
throw new RuntimeException();
}

}