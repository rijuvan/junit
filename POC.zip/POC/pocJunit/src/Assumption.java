import static org.junit.Assert.*;

import org.junit.Assume;
import org.junit.Test;

public class Assumption {
boolean isSonarRunning = false;
@Test
public void very_critical_test() throws Exception {
isSonarRunning = false;
Assume.assumeFalse(isSonarRunning);
assertTrue(true);
}
}