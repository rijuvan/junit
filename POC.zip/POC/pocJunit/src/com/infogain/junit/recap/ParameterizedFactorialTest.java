package com.infogain.junit.recap;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
public class ParameterizedFactorialTest {

@Parameters
  public static Collection<Object[]> factorialData() {
        return Arrays.asList(new Object[][] {
 { 0, 1}, { 1, 1 }, { 2, 2 }, { 3, 6 }, { 4, 24 }, { 5, 120 },{ 6, 720 }  
           });}
    
    private int number;
    private int expectedResult;

    /*
     * The Parameterized runner needs a constructor
     *  to pass the collection of data. For each row
     *   in the collection, the 0th array element will
     *    be passed as the 1st constructor argument, 
     *    the next index will 
     * be passed as 2nd argument, and so on
     */
   public ParameterizedFactorialTest(int input, int expected) {
        number= input;
        expectedResult= expected;
    }
    
    @Test
	public void factorial() throws Exception {
    	Factorial fact = new Factorial();
		assertEquals(fact.factorial(number),expectedResult);
	}
}
