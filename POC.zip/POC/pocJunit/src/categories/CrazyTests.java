package categories;

public interface CrazyTests { /* category marker */ }