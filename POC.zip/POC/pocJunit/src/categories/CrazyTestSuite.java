package categories;
import org.junit.experimental.categories.Categories.IncludeCategory;

import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite.SuiteClasses;
@RunWith(Categories.class)
@IncludeCategory(SmartTests.class)   //(CrazyTests.class)
@SuiteClasses({SomeTest.class, OtherTest.class}) // Note that Categories is a kind of Suite
public class CrazyTestSuite {
// Will run SomeTest.b and OtherTest.c, but not SomeTest.a
}
 /*  @RunWith(Categories.class)
@IncludeCategory(CrazyTests.class)
@ExcludeCategory(SmartTests.class)
@SuiteClasses( { SomeTest.class, OtherTest.class })
public class CrazyTestSuite {
// Will run SomeTest.b, but not SomeTest.a or OtherTest.c
}*/