package categories;

public interface SmartTests { /* category marker */ }
