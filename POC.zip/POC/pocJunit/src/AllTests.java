import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({AssertTest.class, AssertThatTest.class,
		Assumption.class, FirstDayAtSchoolTest.class,
		FirstDayAtSchoolTest2.class, IgnoreTest.class, SanityTest.class,
		StringMatcher.class, TestExecutionOrder.class })
public class AllTests {

}
