import org.junit.*;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.assertThat;

public class StringMatcher {
	@Test
	public void verify_Strings() throws Exception {
	String name = "John Jr Dale";
	assertThat(name, startsWith("John"));
	assertThat(name, endsWith("Dale"));
	assertThat(name, containsString("Jr"));
	}
}
