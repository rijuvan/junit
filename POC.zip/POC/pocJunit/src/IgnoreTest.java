import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;

public class IgnoreTest
{
@Test
@Ignore("This case is going to ignore")
public void when_today_is_holiday_then_stop_alarm() {
	
	Assert.assertNull(3);
}

}