import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;


@RunWith(Suite.class)
@SuiteClasses({ AssertTest.class, AssertThatTest.class, Assumption.class,
		IgnoreTest.class })
public class TestSuiteAll {

}
